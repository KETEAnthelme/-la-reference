# LA RÉFÉRENCE — Gestion scolaire

Version initiale complète de l'interface de gestion scolaire.

## Démarrage
Ouvrir `index.html` dans un navigateur.

Identifiant initial :
- utilisateur : `admin`
- mot de passe : `admin123`

## Modules
Tableau de bord, élèves, enseignants, classes, notes, paiements, présences, emploi du temps, parents, rapports et paramètres.

## Important
Cette version enregistre les données dans le navigateur (`localStorage`). Elle est adaptée pour une maquette fonctionnelle, une démonstration ou une utilisation sur un seul appareil.

Pour une vraie plateforme Internet multi-utilisateurs (direction + enseignants + parents + élèves), il faut connecter cette interface à une base de données et à un système d'authentification côté serveur. Les identifiants ne doivent pas rester ceux de démonstration.

## Déploiement
Le dossier peut être publié sur GitHub Pages, Netlify, Vercel ou un autre hébergeur statique.
