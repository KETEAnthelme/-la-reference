const KEY="lr_school_v1";
let db=JSON.parse(localStorage.getItem(KEY)||"null")||{
 students:[{id:1,name:"Exemple Élève",class:"6e",sex:"M",phone:"",status:"Actif"}],
 teachers:[{id:1,name:"Exemple Enseignant",subject:"Mathématiques",phone:""}],
 classes:[{id:1,name:"6e",level:"Collège",capacity:50}],
 payments:[], grades:[], attendance:[], parents:[],
 settings:{school:"LA RÉFÉRENCE",director:"",phone:"",address:"Cotonou / Abomey-Calavi"}
};
function save(){localStorage.setItem(KEY,JSON.stringify(db));}
function login(){document.getElementById("login").classList.add("hidden");document.getElementById("app").classList.remove("hidden");showPage("dashboard");}
function logout(){location.reload()}
function toggleSide(){document.querySelector(".sidebar").classList.toggle("open")}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function showPage(p){
 document.querySelectorAll(".sidebar nav button").forEach(x=>x.classList.toggle("active",x.dataset.page===p));
 const titles={dashboard:"Tableau de bord",students:"Élèves",teachers:"Enseignants",classes:"Classes",grades:"Notes",payments:"Paiements",attendance:"Présences",schedule:"Emploi du temps",parents:"Parents",reports:"Rapports",settings:"Paramètres"};
 document.getElementById("pageTitle").textContent=titles[p]||p;
 document.getElementById("content").innerHTML=pages[p]();
 document.getElementById("today").textContent=new Date().toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long",year:"numeric"});
}
function pageShell(title,sub,button,onclick,body){return `<div class="page"><div class="page-head"><div><h2>${title}</h2><p>${sub}</p></div>${button?`<button class="btn primary" onclick="${onclick}">${button}</button>`:""}</div>${body}</div>`}
function stat(label,value){return `<div class="card"><div class="muted">${label}</div><div class="metric">${value}</div></div>`}
const pages={
 dashboard:()=>`<div class="page"><div class="page-head"><div><h2>Bienvenue dans LA RÉFÉRENCE</h2><p>Centre de contrôle de votre établissement.</p></div></div><div class="cards">${stat("Élèves",db.students.length)}${stat("Enseignants",db.teachers.length)}${stat("Classes",db.classes.length)}${stat("Paiements",db.payments.length)}</div><div class="dashboard-grid"><div class="card"><h3>Fonctionnalités</h3><p>Gérez les élèves, enseignants, classes, notes, paiements, présences, parents et rapports depuis cette interface.</p><div class="notice">Les données de cette version sont enregistrées dans le navigateur. Pour une utilisation multi-utilisateurs en ligne avec une vraie base de données, une connexion serveur devra être configurée.</div></div><div class="card"><h3>État</h3><p>🟢 Interface opérationnelle</p><p>🔐 Administration locale active</p><p>📱 Compatible téléphone</p></div></div><div class="footer-note">LA RÉFÉRENCE — Gestion scolaire</div></div>`,
 students:()=>listPage("Élèves","Dossiers et inscriptions des élèves","Ajouter un élève","student",db.students,["Nom","Classe","Sexe","Téléphone","Statut"]),
 teachers:()=>listPage("Enseignants","Gestion du personnel enseignant","Ajouter un enseignant","teacher",db.teachers,["Nom","Matière","Téléphone"]),
 classes:()=>listPage("Classes","Classes et niveaux","Ajouter une classe","class",db.classes,["Classe","Niveau","Capacité"]),
 parents:()=>listPage("Parents","Contacts des parents/tuteurs","Ajouter un parent","parent",db.parents,["Nom","Élève","Téléphone","Email"]),
 payments:()=>listPage("Paiements","Suivi des frais de scolarité","Enregistrer un paiement","payment",db.payments,["Élève","Montant","Date","Motif"]),
 grades:()=>listPage("Notes","Saisie et suivi des notes","Ajouter une note","grade",db.grades,["Élève","Matière","Note","Coefficient","Période"]),
 attendance:()=>listPage("Présences","Présences et absences","Enregistrer une présence","attendance",db.attendance,["Élève","Date","État","Motif"]),
 reports:()=>pageShell("Rapports","Synthèse de l'établissement","","",`<div class="cards">${stat("Total élèves",db.students.length)}${stat("Total enseignants",db.teachers.length)}${stat("Total classes",db.classes.length)}${stat("Paiements enregistrés",db.payments.length)}</div><div class="card" style="margin-top:15px"><h3>Exporter les données</h3><p class="muted">Téléchargez une copie JSON de la base locale pour sauvegarde.</p><button class="btn primary" onclick="exportData()">Exporter la sauvegarde</button></div>`),
 schedule:()=>pageShell("Emploi du temps","Organisation hebdomadaire","","",`<div class="table-wrap"><table class="table"><thead><tr><th>Heure</th><th>Lundi</th><th>Mardi</th><th>Mercredi</th><th>Jeudi</th><th>Vendredi</th></tr></thead><tbody>${["08:00–10:00","10:15–12:15","14:00–16:00","16:15–18:15"].map(t=>`<tr><td>${t}</td><td>—</td><td>—</td><td>—</td><td>—</td><td>—</td></tr>`).join("")}</tbody></table></div>`),
 settings:()=>pageShell("Paramètres","Informations de votre établissement","Enregistrer","saveSettings",`<div class="card"><div class="form-grid"><label>Nom de l'établissement<input id="setSchool" value="${esc(db.settings.school)}"></label><label>Directeur<input id="setDirector" value="${esc(db.settings.director)}"></label><label>Téléphone<input id="setPhone" value="${esc(db.settings.phone)}"></label><label>Adresse<input id="setAddress" value="${esc(db.settings.address)}"></label></div></div>`)
};
function listPage(title,sub,btn,type,arr,cols){
 let rows=arr.map((x,i)=>`<tr>${cols.map(c=>`<td>${esc(rowVal(x,c))}</td>`).join("")}<td><button class="btn danger" onclick="removeItem('${type}',${x.id})">Supprimer</button></td></tr>`).join("");
 return pageShell(title,sub,btn,`openForm('${type}')`,`<div class="toolbar"><input placeholder="Rechercher..." oninput="filterTable(this)"></div><div class="table-wrap"><table class="table"><thead><tr>${cols.map(c=>`<th>${c}</th>`).join("")}<th>Action</th></tr></thead><tbody id="dataBody">${rows||`<tr><td colspan="${cols.length+1}" class="empty">Aucune donnée.</td></tr>`}</tbody></table></div>`);
}
function rowVal(x,c){return ({Nom:x.name||x.student||"",Classe:x.class||"",Sexe:x.sex||"",Téléphone:x.phone||"",Statut:x.status||"",Matière:x.subject||x.matter||"",Niveau:x.level||"",Capacité:x.capacity||"",Élève:x.student||"",Email:x.email||"",Montant:x.amount?x.amount+" FCFA":"",Date:x.date||"",Motif:x.reason||"",Note:x.note??"",Coefficient:x.coeff??"",Période:x.period||"",État:x.state||""})[c]??""}
function filterTable(inp){let q=inp.value.toLowerCase();document.querySelectorAll("#dataBody tr").forEach(r=>r.style.display=r.innerText.toLowerCase().includes(q)?"":"none")}
function openForm(type){
 const forms={
 student:["Ajouter un élève",`<div class="form-grid"><input id="f_name" placeholder="Nom et prénom"><input id="f_class" placeholder="Classe"><select id="f_sex"><option>M</option><option>F</option></select><input id="f_phone" placeholder="Téléphone"><select id="f_status"><option>Actif</option><option>Inactif</option></select></div>`],
 teacher:["Ajouter un enseignant",`<div class="form-grid"><input id="f_name" placeholder="Nom et prénom"><input id="f_subject" placeholder="Matière"><input id="f_phone" placeholder="Téléphone"></div>`],
 class:["Ajouter une classe",`<div class="form-grid"><input id="f_name" placeholder="Nom de la classe"><input id="f_level" placeholder="Niveau"><input id="f_capacity" type="number" placeholder="Capacité"></div>`],
 parent:["Ajouter un parent",`<div class="form-grid"><input id="f_name" placeholder="Nom du parent"><input id="f_student" placeholder="Nom de l'élève"><input id="f_phone" placeholder="Téléphone"><input id="f_email" placeholder="Email"></div>`],
 payment:["Enregistrer un paiement",`<div class="form-grid"><input id="f_student" placeholder="Nom de l'élève"><input id="f_amount" type="number" placeholder="Montant FCFA"><input id="f_date" type="date"><input id="f_reason" placeholder="Motif"></div>`],
 grade:["Ajouter une note",`<div class="form-grid"><input id="f_student" placeholder="Nom de l'élève"><input id="f_matter" placeholder="Matière"><input id="f_note" type="number" step="0.01" placeholder="Note /20"><input id="f_coeff" type="number" value="1" placeholder="Coefficient"><input id="f_period" placeholder="Période"></div>`],
 attendance:["Enregistrer une présence",`<div class="form-grid"><input id="f_student" placeholder="Nom de l'élève"><input id="f_date" type="date"><select id="f_state"><option>Présent</option><option>Absent</option><option>Retard</option></select><input id="f_reason" placeholder="Motif"></div>`]
 };
 const [title,body]=forms[type]; document.getElementById("modalTitle").textContent=title;document.getElementById("modalBody").innerHTML=body+`<button class="btn primary" onclick="saveForm('${type}')">Enregistrer</button>`;document.getElementById("modal").classList.remove("hidden");
}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
function val(id){return document.getElementById(id)?.value||""}
function saveForm(type){
 let id=Date.now(), x={id};
 if(type==="student")Object.assign(x,{name:val("f_name"),class:val("f_class"),sex:val("f_sex"),phone:val("f_phone"),status:val("f_status")});
 if(type==="teacher")Object.assign(x,{name:val("f_name"),subject:val("f_subject"),phone:val("f_phone")});
 if(type==="class")Object.assign(x,{name:val("f_name"),level:val("f_level"),capacity:val("f_capacity")});
 if(type==="parent")Object.assign(x,{name:val("f_name"),student:val("f_student"),phone:val("f_phone"),email:val("f_email")});
 if(type==="payment")Object.assign(x,{student:val("f_student"),amount:val("f_amount"),date:val("f_date")||new Date().toISOString().slice(0,10),reason:val("f_reason")});
 if(type==="grade")Object.assign(x,{student:val("f_student"),matter:val("f_matter"),note:val("f_note"),coeff:val("f_coeff"),period:val("f_period")});
 if(type==="attendance")Object.assign(x,{student:val("f_student"),date:val("f_date")||new Date().toISOString().slice(0,10),state:val("f_state"),reason:val("f_reason")});
 const map={student:"students",teacher:"teachers",class:"classes",parent:"parents",payment:"payments",grade:"grades",attendance:"attendance"};db[map[type]].push(x);save();closeModal();showPage(type==="student"?"students":type==="teacher"?"teachers":type==="class"?"classes":type==="parent"?"parents":type==="payment"?"payments":type==="grade"?"grades":"attendance");
}
function removeItem(type,id){if(!confirm("Supprimer cet élément ?"))return;const map={student:"students",teacher:"teachers",class:"classes",parent:"parents",payment:"payments",grade:"grades",attendance:"attendance"};db[map[type]]=db[map[type]].filter(x=>x.id!==id);save();showPage(document.querySelector(".sidebar nav button.active")?.dataset.page||"dashboard")}
function saveSettings(){db.settings={school:val("setSchool"),director:val("setDirector"),phone:val("setPhone"),address:val("setAddress")};save();alert("Paramètres enregistrés.");}
function exportData(){const blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="la-reference-sauvegarde.json";a.click();URL.revokeObjectURL(a.href)}
